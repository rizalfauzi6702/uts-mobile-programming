package com.example.rayhan.uts;

import
        android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;



public class Activity_PengaduanWarga extends AppCompatActivity {
    ArrayList<Datalist> arrayList = new ArrayList<Datalist>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pengaduanwarga);
    }

    public void komen (View v){

        ListView listView = (ListView) findViewById(R.id.listpengaduan);
        DataAdapter adapter = new DataAdapter(this, R.layout.row, arrayList);
        listView.setAdapter(adapter);

        EditText komentar = (EditText) findViewById(R.id.komentar);
       // Button buttonkomen = (Button) findViewById(R.id.buttonkomen);
        String pesan = komentar.getText().toString();
        arrayList.add(new Datalist(pesan));

     /*   EditText komentar = (EditText) findViewById(R.id.komentar);
        String pesan = komentar.getText().toString();

        Intent in = new Intent(getApplicationContext(), Activity_List.class);
        in.putExtra("datadaripengaduan",pesan);
        startActivityForResult(in,99);*/



    }
}
