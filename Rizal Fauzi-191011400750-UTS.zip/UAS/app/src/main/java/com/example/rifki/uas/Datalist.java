package com.example.rifki.uas;

/**

 */

public class Datalist {

    public String komen;

    public Datalist (String komen){
        this.komen=komen;
    }
}
