package com.example.rifki.uas;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by user on 07/12/2017.
 */

public class Activity_List extends AppCompatActivity {

    ArrayList<Datalist> arrayList = new ArrayList<Datalist>();

    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.timeline);
        arrayList.add(new Datalist("test"));
        ListView listview = (ListView) findViewById(R.id.timeline);
        DataAdapter adapter = new DataAdapter(this,R.layout.row, arrayList);
        listview.setAdapter(adapter);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Intent in = getIntent();

        String msg = in.getStringExtra("datadaripengaduan");
        TextView komentar = (TextView) findViewById(R.id.komentar);
        komentar.setText(msg);
    }
}
